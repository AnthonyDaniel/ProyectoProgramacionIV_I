<?php echo e($slot); ?>

<?php /**PATH C:\Users\Thony\Desktop\Laravel-Angular Final\BackEnd\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>