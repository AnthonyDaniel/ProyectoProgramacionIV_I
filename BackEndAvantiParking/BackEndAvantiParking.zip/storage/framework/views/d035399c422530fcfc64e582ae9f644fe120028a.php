<?php $__env->startComponent('mail::message'); ?>
# Change your password

Click on the button below to change password

<?php $__env->startComponent('mail::button', ['url' => 'http://localhost:4200/response-password-reset?token='.
$token]); ?>
RESET PASSWORD
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
Avantica
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Thony\Desktop\Laravel-Angular Final\BackEnd\resources\views/Email/passwordReset.blade.php ENDPATH**/ ?>