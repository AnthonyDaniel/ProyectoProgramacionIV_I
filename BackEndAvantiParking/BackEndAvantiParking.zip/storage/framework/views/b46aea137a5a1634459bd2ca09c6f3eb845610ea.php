<?php echo e($slot); ?>

<?php /**PATH C:\Users\Thony\Desktop\Angular && Laravel\ProyectoProgramacionIV_I\BackEndAvantiParking\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>